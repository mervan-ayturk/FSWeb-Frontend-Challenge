import React, { useEffect, useContext } from 'react';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { SiteProvider, SiteContext } from './context/SiteContext';
import Header from './components/Header';
import Hero from './components/Hero';
import Skills from './components/Skills';
import Profile from './components/Profile';
import Projects from './components/Projects';
import Footer from './components/Footer';

// Inner component that can access context
const AppContent = () => {
  const { postDataToApi, theme } = useContext(SiteContext);

  useEffect(() => {
    // Send initial data to API on load
    postDataToApi();
  }, []); // Run only once

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <Skills />
        <Profile />
        <Projects />
      </main>
      <Footer />
      <ToastContainer 
        position="bottom-right" 
        theme={theme === 'dark' ? 'dark' : 'light'} 
      />
    </div>
  );
};

// Main App component wraps everything in Provider
function App() {
  return (
    <SiteProvider>
      <AppContent />
    </SiteProvider>
  );
}

export default App;
