import React, { createContext, useState, useEffect } from 'react';
import data from '../data.json';
import axios from 'axios';
import { toast } from 'react-toastify';

export const SiteContext = createContext();

export const SiteProvider = ({ children }) => {
  // Theme state
  const [theme, setTheme] = useState('light');

  // Language state
  const [language, setLanguage] = useState('en');

  // Data state based on language
  const [siteData, setSiteData] = useState(data.en);

  // Initialize theme from system or local storage
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme) {
      setTheme(savedTheme);
      if (savedTheme === 'dark') {
        document.documentElement.classList.add('dark');
      }
    } else if (prefersDark) {
      setTheme('dark');
      document.documentElement.classList.add('dark');
    }
  }, []);

  // Initialize language from local storage
  useEffect(() => {
    const savedLanguage = localStorage.getItem('language');
    if (savedLanguage && (savedLanguage === 'en' || savedLanguage === 'tr')) {
      setLanguage(savedLanguage);
      setSiteData(data[savedLanguage]);
    }
  }, []);

  // Toggle theme
  const toggleTheme = () => {
    setTheme((prevTheme) => {
      const newTheme = prevTheme === 'light' ? 'dark' : 'light';
      localStorage.setItem('theme', newTheme);
      
      if (newTheme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      
      return newTheme;
    });
  };

  // Toggle language
  const toggleLanguage = () => {
    setLanguage((prevLang) => {
      const newLang = prevLang === 'en' ? 'tr' : 'en';
      localStorage.setItem('language', newLang);
      setSiteData(data[newLang]);
      return newLang;
    });
  };

  // Handle API POST request example (Reqres API)
  const postDataToApi = async () => {
    try {
      const payload = {
        theme,
        language,
        timestamp: new Date().toISOString()
      };
      
      const response = await axios.post('https://reqres.in/api/workintech', payload);
      console.log('API Response:', response.data);
      toast.success(language === 'en' ? 'Data sent successfully!' : 'Veri başarıyla gönderildi!');
    } catch (error) {
      console.error('API Error:', error);
      toast.error(language === 'en' ? 'Error sending data.' : 'Veri gönderme hatası.');
    }
  };

  return (
    <SiteContext.Provider value={{ theme, toggleTheme, language, toggleLanguage, siteData, postDataToApi }}>
      {children}
    </SiteContext.Provider>
  );
};
