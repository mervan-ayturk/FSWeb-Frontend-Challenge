import React, { useContext } from 'react';
import { SiteContext } from '../context/SiteContext';

const Footer = () => {
  const { siteData } = useContext(SiteContext);
  const { footer } = siteData;

  return (
    <footer className="bg-[#F9F9F9] dark:bg-[#1A210B] transition-colors duration-300 py-20 relative overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-6 relative z-10 flex flex-col items-center text-center">
        <h2 className="text-4xl md:text-6xl font-bold text-[#4832D3] dark:text-[#8F88FF] mb-12 max-w-3xl leading-tight">
          {footer.title}
        </h2>
        
        <div className="flex flex-col md:flex-row items-center gap-8 text-lg">
          <a href={`mailto:${footer.email}`} className="text-[#AF0C48] dark:text-[#BAB2E7] font-semibold flex items-center gap-2">
             <span role="img" aria-label="email">👉</span>
             {footer.email}
          </a>
          <a href="#" className="text-black dark:text-white hover:text-[#4832D3] dark:hover:text-[#CBF281] transition-colors">
            {footer.personalBlog}
          </a>
          <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-[#00AB6B] dark:text-[#17D18B] hover:opacity-80 transition-opacity">
            {footer.github}
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-[#0077B5] dark:text-[#0BA6F6] hover:opacity-80 transition-opacity">
            {footer.linkedin}
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
