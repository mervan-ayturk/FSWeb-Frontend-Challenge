import React, { useContext } from 'react';
import { SiteContext } from '../context/SiteContext';

const Projects = () => {
  const { siteData } = useContext(SiteContext);
  const { projects } = siteData;

  // Placeholder images for projects
  const projectImages = [
    "https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  ];

  return (
    <section className="bg-white dark:bg-[#252128] transition-colors duration-300 py-20">
      <div className="max-w-[1200px] mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-bold text-[#4832D3] dark:text-[#CBF281] mb-12">
          {projects.title}
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {projects.list.map((project, index) => (
            <div key={project.id} className="flex flex-col">
              <div className="w-full h-[300px] mb-6 rounded-lg overflow-hidden relative bg-gray-100 dark:bg-gray-800">
                <img 
                  src={projectImages[index % projectImages.length]} 
                  alt={project.title} 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-3xl font-bold text-[#4832D3] dark:text-[#8F88FF] mb-4">
                {project.title}
              </h3>
              <p className="text-[#777777] dark:text-white/80 leading-relaxed text-sm mb-6 flex-grow">
                {project.description}
              </p>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {project.tech.map((t, i) => (
                  <span key={i} className="px-4 py-1.5 bg-[#4731D3] text-white dark:bg-[#8F88FF] dark:text-black rounded-full text-xs font-semibold tracking-wider">
                    {t}
                  </span>
                ))}
              </div>
              
              <div className="flex items-center gap-8 font-semibold text-sm">
                <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-[#3730A3] dark:text-[#CBF281] hover:underline underline-offset-4">
                  {project.github}
                </a>
                <a href="#" className="text-[#3730A3] dark:text-[#CBF281] hover:underline underline-offset-4 flex items-center gap-1">
                  {project.site}
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path d="M11.6667 7.58334V12.25C11.6667 12.5594 11.5437 12.8562 11.325 13.0749C11.1062 13.2937 10.8094 13.4167 10.5 13.4167H1.75C1.44058 13.4167 1.14383 13.2937 0.925042 13.0749C0.706249 12.8562 0.583333 12.5594 0.583333 12.25V3.50001C0.583333 3.19059 0.706249 2.89384 0.925042 2.67505C1.14383 2.45626 1.44058 2.33334 1.75 2.33334H6.41667V3.50001H1.75V12.25H10.5V7.58334H11.6667ZM8.16667 0.583344V1.75001H10.8417L4.76 7.83168L5.58833 8.66001L11.6667 2.58168V5.25001H12.8333V0.583344H8.16667Z"/>
                  </svg>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
