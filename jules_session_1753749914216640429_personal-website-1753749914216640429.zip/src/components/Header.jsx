import React, { useContext } from 'react';
import { SiteContext } from '../context/SiteContext';

const Header = () => {
  const { theme, toggleTheme, language, toggleLanguage, siteData } = useContext(SiteContext);
  const { header } = siteData;

  return (
    <header className="flex justify-end items-center py-6 max-w-[1200px] mx-auto px-6 lg:px-0">
      <div className="flex items-center space-x-6 text-sm font-semibold tracking-wider">
        {/* Language Toggle */}
        <button 
          onClick={toggleLanguage}
          className="text-[#777777] dark:text-[#777777] hover:text-[#4731D3] dark:hover:text-[#8F88FF] transition-colors flex items-center gap-1"
        >
          {header.languageTogglePrefix && <span>{header.languageTogglePrefix}</span>}
          <span className="text-[#4731D3] dark:text-[#8F88FF]">{header.languageToggle}</span>
          {header.languageToggleSuffix && <span>{header.languageToggleSuffix}</span>}
        </button>

        {/* Theme Toggle */}
        <div className="flex items-center space-x-2">
          <button 
            onClick={toggleTheme}
            className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 ease-in-out flex items-center ${theme === 'dark' ? 'bg-[#3A3A3A] justify-end' : 'bg-[#4731D3] justify-start'}`}
            aria-label="Toggle Dark Mode"
          >
            <div className={`w-4 h-4 rounded-full transition-transform duration-300 ease-in-out ${theme === 'dark' ? 'bg-white' : 'bg-[#FFE86E]'}`}></div>
          </button>
          <span className="text-[#777777] dark:text-[#777777] font-bold">
            {theme === 'dark' ? header.lightMode : header.darkMode}
          </span>
        </div>
      </div>
    </header>
  );
};

export default Header;
