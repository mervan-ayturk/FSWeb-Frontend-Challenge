import React, { useContext } from 'react';
import { SiteContext } from '../context/SiteContext';

const Hero = () => {
  const { siteData } = useContext(SiteContext);
  const { hero } = siteData;

  return (
    <section className="bg-[#4731D3] dark:bg-[#171043] transition-colors duration-300">
      <div className="max-w-[1200px] mx-auto px-6 py-20 flex flex-col md:flex-row items-center gap-12">
        <div className="flex-1 text-white">
          <div className="flex items-center gap-4 mb-6">
            <span className="w-24 h-[1px] bg-[#CBF281]"></span>
            <span className="text-[#CBF281] font-medium tracking-wide">ALMİLA SU</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight tracking-tighter">
            {hero.greeting.split(' ').map((word, i) => (
              <React.Fragment key={i}>
                {word} <br />
              </React.Fragment>
            ))}
          </h1>
          <p className="text-lg md:text-xl text-white/80 mb-10 max-w-[500px] leading-relaxed">
            {hero.intro}
          </p>
          <div className="flex flex-wrap gap-4">
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="px-8 py-3 bg-white text-[#3730A3] dark:bg-[#252128] dark:text-white rounded-md font-medium hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors flex items-center gap-2">
              <svg width="24" height="25" viewBox="0 0 24 25" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 0.5C5.37 0.5 0 5.87 0 12.5C0 17.8 3.438 22.31 8.205 23.88C8.805 23.99 9.025 23.62 9.025 23.31C9.025 23.03 9.015 22.28 9.01 21.3C5.672 22.02 4.968 19.69 4.968 19.69C4.422 18.3 3.633 17.93 3.633 17.93C2.546 17.18 3.717 17.2 3.717 17.2C4.922 17.28 5.555 18.44 5.555 18.44C6.627 20.28 8.364 19.75 9.05 19.44C9.158 18.66 9.471 18.13 9.816 17.83C7.145 17.53 4.344 16.5 4.344 11.87C4.344 10.55 4.815 9.47 5.59 8.63C5.465 8.33 5.05 7.1 5.71 5.43C5.71 5.43 6.726 5.1 9.01 6.65C9.975 6.38 10.995 6.25 12 6.24C13.005 6.25 14.025 6.38 14.99 6.65C17.274 5.1 18.29 5.43 18.29 5.43C18.95 7.1 18.535 8.33 18.41 8.63C19.185 9.47 19.656 10.55 19.656 11.87C19.656 16.51 16.85 17.53 14.17 17.83C14.6 18.2 14.985 18.92 14.985 20.06C14.985 21.69 14.97 23.01 14.97 23.31C14.97 23.62 15.19 23.99 15.795 23.88C20.562 22.31 24 17.8 24 12.5C24 5.87 18.63 0.5 12 0.5Z"/>
              </svg>
              {hero.github}
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="px-8 py-3 bg-white text-[#3730A3] dark:bg-[#252128] dark:text-white rounded-md font-medium hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors flex items-center gap-2">
              <svg width="24" height="25" viewBox="0 0 24 25" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M4.98 3.5C4.98 4.881 3.861 6 2.49 6C1.119 6 0 4.881 0 3.5C0 2.119 1.119 1 2.49 1C3.861 1 4.98 2.119 4.98 3.5ZM0.435 24H4.545V8H0.435V24ZM14.935 8.01C12.785 8.01 11.455 9.17 10.875 10.15V8.19H6.945C6.995 9.35 6.945 24 6.945 24H11.055V15.11C11.055 14.63 11.085 14.16 11.235 13.82C11.645 12.87 12.525 11.89 13.965 11.89C15.895 11.89 16.665 13.36 16.665 15.52V24H20.775V14.93C20.775 10.08 18.175 8.01 14.935 8.01Z"/>
              </svg>
              {hero.linkedin}
            </a>
          </div>
        </div>
        <div className="flex-1 w-full flex justify-center md:justify-end">
          <div className="w-[300px] h-[300px] md:w-[400px] md:h-[400px] rounded-2xl overflow-hidden relative shadow-xl">
             <div className="absolute inset-0 bg-[#CBF281] mix-blend-multiply opacity-20"></div>
             {/* You would use an actual image here, keeping a placeholder for now or using an unspash URL */}
             <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Almila" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
