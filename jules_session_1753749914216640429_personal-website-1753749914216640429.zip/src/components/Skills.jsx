import React, { useContext } from 'react';
import { SiteContext } from '../context/SiteContext';

const Skills = () => {
  const { siteData } = useContext(SiteContext);
  const { skills } = siteData;

  return (
    <section className="bg-white dark:bg-[#252128] transition-colors duration-300 py-20">
      <div className="max-w-[1200px] mx-auto px-6 flex flex-col md:flex-row gap-12 md:gap-24">
        <h2 className="text-4xl md:text-5xl font-bold text-[#4832D3] dark:text-[#CBF281] shrink-0 md:w-1/3">
          {skills.title}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {skills.list.map((skill, index) => (
            <div key={index} className="flex flex-col gap-4">
              <h3 className="text-2xl font-semibold text-[#4832D3] dark:text-[#8F88FF]">
                {skill.name}
              </h3>
              <p className="text-[#777777] dark:text-white/80 leading-relaxed text-sm">
                {skill.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
