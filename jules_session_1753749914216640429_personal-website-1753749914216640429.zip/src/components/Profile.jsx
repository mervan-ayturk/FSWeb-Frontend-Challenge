import React, { useContext } from 'react';
import { SiteContext } from '../context/SiteContext';

const Profile = () => {
  const { siteData } = useContext(SiteContext);
  const { profile } = siteData;

  return (
    <section className="bg-[#F4F4F4] dark:bg-[#1A210B] transition-colors duration-300 py-20 relative overflow-hidden">
      {/* Decorative circle */}
      <div className="absolute right-[-100px] top-1/2 -translate-y-1/2 w-64 h-64 border-[16px] border-[#D9D9D9] dark:border-[#525252]/20 rounded-full"></div>
      
      <div className="max-w-[1200px] mx-auto px-6 relative z-10 flex flex-col md:flex-row gap-12 md:gap-24">
        <h2 className="text-4xl md:text-5xl font-bold text-[#4832D3] dark:text-[#CBF281] shrink-0 md:w-1/3">
          {profile.title}
        </h2>
        
        <div className="flex flex-col md:flex-row gap-16 w-full">
          {/* Basic Info */}
          <div className="flex-1">
            <h3 className="text-2xl font-semibold mb-6 text-[#4832D3] dark:text-white">
              {profile.basicInfo.title}
            </h3>
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:gap-4 border-b border-[#E6E6E6] dark:border-white/10 pb-4">
                <span className="w-40 text-black dark:text-white font-semibold">{profile.basicInfo.birthDate}</span>
                <span className="text-black dark:text-white">{profile.basicInfo.birthDateValue}</span>
              </div>
              <div className="flex flex-col sm:flex-row sm:gap-4 border-b border-[#E6E6E6] dark:border-white/10 pb-4">
                <span className="w-40 text-black dark:text-white font-semibold">{profile.basicInfo.city}</span>
                <span className="text-black dark:text-white">{profile.basicInfo.cityValue}</span>
              </div>
              <div className="flex flex-col sm:flex-row sm:gap-4 border-b border-[#E6E6E6] dark:border-white/10 pb-4">
                <span className="w-40 text-black dark:text-white font-semibold">{profile.basicInfo.education}</span>
                <span className="text-black dark:text-white">{profile.basicInfo.educationValue}</span>
              </div>
              <div className="flex flex-col sm:flex-row sm:gap-4 border-b border-[#E6E6E6] dark:border-white/10 pb-4">
                <span className="w-40 text-black dark:text-white font-semibold">{profile.basicInfo.role}</span>
                <span className="text-black dark:text-white">{profile.basicInfo.roleValue}</span>
              </div>
            </div>
          </div>
          
          {/* About */}
          <div className="flex-1">
            <h3 className="text-2xl font-semibold mb-6 text-[#4832D3] dark:text-white">
              {profile.about.title}
            </h3>
            <div className="space-y-4 text-[#777777] dark:text-white/80 leading-relaxed text-sm">
              <p>{profile.about.description1}</p>
              <p>{profile.about.description2}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Profile;
